from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from .db import init_db
from .routers import imports, leads

app = FastAPI(title="ClaimScraperCRM")
app.include_router(imports.router)
app.include_router(leads.router)
app.mount('/static', StaticFiles(directory='static'), name='static')

@app.on_event("startup")
def on_startup():
    init_db()