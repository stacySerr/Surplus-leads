from typing import Optional, Dict, Any
from datetime import datetime
from sqlmodel import SQLModel, Field, Column, JSON

class LeadBase(SQLModel):
    full_name: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    entity_type: Optional[str] = None  # person/company/estate

    phone: Optional[str] = None
    alt_phone: Optional[str] = None
    email: Optional[str] = None

    address1: Optional[str] = None
    address2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    postal: Optional[str] = None
    county: Optional[str] = None

    apn: Optional[str] = None
    case_number: Optional[str] = None
    docket: Optional[str] = None
    claim_type: Optional[str] = None  # tax_overage, foreclosure_excess, unclaimed_funds, sheriff_sale, other

    amount: Optional[float] = None
    source: Optional[str] = None
    source_url: Optional[str] = None

    status: Optional[str] = "new"  # new, researching, contacted, under_contract, claimed, paid, bad
    tags: Optional[str] = None
    notes: Optional[str] = None

    extras: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))

class Lead(LeadBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class Note(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    lead_id: int = Field(foreign_key="lead.id")
    body: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Task(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    lead_id: int = Field(foreign_key="lead.id")
    title: str
    due_date: Optional[datetime] = None
    done: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)