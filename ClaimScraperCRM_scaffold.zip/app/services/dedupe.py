from typing import List, Tuple
from rapidfuzz import fuzz

# Very simple blocking + scoring
def candidate_pairs(rows: list[dict]) -> List[Tuple[int,int]]:
    # Block on (state, county) to narrow comparisons
    index = {}
    for i, r in enumerate(rows):
        key = (r.get("state"), r.get("county"))
        index.setdefault(key, []).append(i)
    pairs = []
    for bucket in index.values():
        n = len(bucket)
        for a in range(n):
            for b in range(a+1, n):
                pairs.append((bucket[a], bucket[b]))
    return pairs

def score_pair(a: dict, b: dict) -> float:
    s = 0.0
    weights = 0.0
    # name
    if a.get('full_name') and b.get('full_name'):
        s += fuzz.token_set_ratio(a['full_name'], b['full_name']) * 0.4; weights += 0.4
    # address
    if a.get('address1') and b.get('address1'):
        s += fuzz.token_set_ratio(a['address1'], b['address1']) * 0.3; weights += 0.3
    # phone
    if a.get('phone') and b.get('phone'):
        s += (100.0 if a['phone'] == b['phone'] else 0.0) * 0.2; weights += 0.2
    # amount
    if a.get('amount') is not None and b.get('amount') is not None:
        s += (100.0 if abs(a['amount'] - b['amount']) < 1e-6 else 0.0) * 0.1; weights += 0.1
    return s / (weights or 1.0)

def find_duplicates(rows: list[dict], threshold: float = 85.0):
    pairs = candidate_pairs(rows)
    dups = []
    for i, j in pairs:
        sc = score_pair(rows[i], rows[j])
        if sc >= threshold:
            dups.append((i, j, sc))
    return dups