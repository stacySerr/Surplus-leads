import re

STATE_MAP = {
    'ca': 'CA', 'california': 'CA',
    'fl': 'FL', 'florida': 'FL',
    'oh': 'OH', 'ohio': 'OH',
    'mn': 'MN', 'minnesota': 'MN',
    'az': 'AZ', 'arizona': 'AZ',
    # add as needed
}

def norm_state(s: str|None) -> str|None:
    if not s: return None
    k = s.strip().lower()
    return STATE_MAP.get(k, s.strip().upper())

def norm_phone(p: str|None) -> str|None:
    if not p: return None
    digits = re.sub(r"\D+", "", p)
    if len(digits) == 10:
        return f"({digits[0:3]}) {digits[3:6]}-{digits[6:]}"
    if len(digits) == 11 and digits[0] == '1':
        return f"({digits[1:4]}) {digits[4:7]}-{digits[7:]}"
    return p.strip()

def norm_name(n: str|None) -> str|None:
    return n.strip().title() if n else None

def norm_county(c: str|None) -> str|None:
    if not c: return None
    c = c.strip()
    if c.lower().endswith('county'):
        return c[:-6].strip().title() + " County"
    return c.title()

def norm_postal(z: str|None) -> str|None:
    if not z: return None
    return re.sub(r"\D+", "", z)[0:5]