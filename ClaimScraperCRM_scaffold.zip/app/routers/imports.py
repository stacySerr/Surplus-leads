import io
from typing import List, Dict, Any
from fastapi import APIRouter, UploadFile, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
import pandas as pd
from sqlmodel import Session
from ..db import get_session
from ..models import Lead
from ..services.normalize import norm_state, norm_phone, norm_name, norm_county, norm_postal
from jinja2 import Environment, FileSystemLoader, select_autoescape

router = APIRouter()
jenv = Environment(loader=FileSystemLoader('templates'), autoescape=select_autoescape())

STANDARD_COLUMNS = [
    'full_name','first_name','last_name','entity_type','phone','alt_phone','email',
    'address1','address2','city','state','postal','county','apn','case_number','docket',
    'claim_type','amount','source','source_url','status','tags','notes'
]

@router.get("/import", response_class=HTMLResponse)
def import_form(request: Request):
    tpl = jenv.get_template("import_form.html")
    return tpl.render()

@router.post("/import/preview", response_class=HTMLResponse)
async def import_preview(file: UploadFile, request: Request):
    content = await file.read()
    df = pd.read_csv(io.BytesIO(content)) if file.filename.endswith(".csv") else pd.read_excel(io.BytesIO(content))
    headers = list(df.columns)
    tpl = jenv.get_template("import_preview.html")
    return tpl.render(headers=headers, standard=STANDARD_COLUMNS, sample=df.head(8).to_dict(orient="records"))

@router.post("/import/commit", response_class=HTMLResponse)
async def import_commit(
    request: Request,
    file: UploadFile,
    mapping: str = Form(...),
    default_state: str = Form(None),
    default_county: str = Form(None),
    default_claim_type: str = Form(None),
    session: Session = Depends(get_session)
):
    content = await file.read()
    df = pd.read_csv(io.BytesIO(content)) if file.filename.endswith(".csv") else pd.read_excel(io.BytesIO(content))
    map_dict: Dict[str,str] = {k:v for k,v in (x.split(':') for x in mapping.split(',')) if v}

    # Build rows with mapping
    rows = []
    for _, row in df.iterrows():
        rec = {col: None for col in STANDARD_COLUMNS}
        extras: Dict[str, Any] = {}
        for src_col, target in map_dict.items():
            val = row.get(src_col, None)
            if target in STANDARD_COLUMNS:
                rec[target] = None if pd.isna(val) else str(val)
            else:
                extras[target] = None if pd.isna(val) else str(val)
        # defaults
        rec['state'] = rec['state'] or default_state
        rec['county'] = rec['county'] or default_county
        rec['claim_type'] = rec['claim_type'] or default_claim_type
        # normalize
        rec['full_name'] = norm_name(rec['full_name'])
        rec['first_name'] = norm_name(rec['first_name'])
        rec['last_name'] = norm_name(rec['last_name'])
        rec['phone'] = norm_phone(rec['phone'])
        rec['alt_phone'] = norm_phone(rec['alt_phone'])
        rec['state'] = norm_state(rec['state'])
        rec['county'] = norm_county(rec['county'])
        rec['postal'] = norm_postal(rec['postal'])
        # amount to float
        if rec['amount'] is not None:
            try:
                rec['amount'] = float(str(rec['amount']).replace('$','').replace(',',''))
            except:
                rec['amount'] = None
        # to Lead model
        lead = Lead(**rec, extras=extras)
        rows.append(lead)

    # bulk insert
    session.add_all(rows)
    session.commit()

    tpl = jenv.get_template("import_done.html")
    return tpl.render(count=len(rows))