from typing import Optional
from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlmodel import Session, select
from ..db import get_session
from ..models import Lead
from jinja2 import Environment, FileSystemLoader, select_autoescape

router = APIRouter()
jenv = Environment(loader=FileSystemLoader('templates'), autoescape=select_autoescape())

@router.get("/", response_class=HTMLResponse)
def home(request: Request, q: Optional[str] = None, state: Optional[str] = None, county: Optional[str] = None, status: Optional[str] = None, min_amount: Optional[float] = None, max_amount: Optional[float] = None, session: Session = Depends(get_session)):
    stmt = select(Lead)
    if q:
        # very simple naive filter
        # note: SQLite LIKE is case-insensitive for ASCII by default
        like = f"%{q}%"
        stmt = stmt.where((Lead.full_name.like(like)) | (Lead.city.like(like)) | (Lead.case_number.like(like)) | (Lead.apn.like(like)))
    if state:
        stmt = stmt.where(Lead.state == state)
    if county:
        stmt = stmt.where(Lead.county == county)
    if status:
        stmt = stmt.where(Lead.status == status)
    if min_amount is not None:
        stmt = stmt.where(Lead.amount >= min_amount)
    if max_amount is not None:
        stmt = stmt.where(Lead.amount <= max_amount)

    leads = list(Session.exec(session, stmt))
    tpl = jenv.get_template("home.html")
    return tpl.render(leads=leads, total=len(leads))

@router.get("/lead/{lead_id}", response_class=HTMLResponse)
def lead_detail(lead_id: int, request: Request, session: Session = Depends(get_session)):
    lead = session.get(Lead, lead_id)
    tpl = jenv.get_template("lead_detail.html")
    return tpl.render(lead=lead)