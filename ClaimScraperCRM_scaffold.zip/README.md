# ClaimScraperCRM (FastAPI + SQLite + HTMX)

A lightweight, import-first CRM for surplus funds / excess proceeds leads.
Designed for Replit (or local). Upload CSV/Excel, map columns, preview, import,
dedupe, search, tag, and export.

## Quickstart (Replit or local)
1) Create a new Repl (Python) or clone locally.
2) Add these files. `pip install -r requirements.txt`
3) Run: `uvicorn app.main:app --reload --host 0.0.0.0 --port 8000`
4) Open http://localhost:8000

## Features
- CSV upload with header detection
- Column mapping into a standard schema
- Preview + bulk import
- Normalization (names/phones/addresses), county/state canonicalization
- Fuzzy de-duplication using RapidFuzz (block on state/county, compare name/address/phone)
- Search + filters (state, county, amount range, status, tags)
- Lead detail page with timeline notes & tasks
- Export filtered results to CSV

## Standard Schema (leads table)
- id (int, PK)
- created_at, updated_at (timestamps)
- full_name, first_name, last_name
- entity_type (person/company/estate)
- phone, alt_phone, email
- address1, address2, city, state, postal, county
- apn (Assessor Parcel Number), case_number, docket
- claim_type (tax_overage, foreclosure_excess, unclaimed_funds, sheriff_sale, other)
- amount (float, USD)
- source (site/file), source_url
- status (new, researching, contacted, under_contract, claimed, paid, bad)
- tags (csv string)
- notes (text)

## Import tips
- Any column can be mapped; unmapped columns are stored in a JSON `extras` field.
- Works best if your CSV has headers.
- After import, run the **Dedupe** page to merge likely duplicates.

## License
MIT